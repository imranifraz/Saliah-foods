import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Header } from "./components/layout/Header";
import { Footer } from "./components/layout/Footer";
import { StructuredData } from "./components/seo/StructuredData";
import { HomePage } from "./pages/HomePage";
import { ProductListingPage } from "./pages/ProductListingPage";
import { SourcingQualityPage } from "./pages/SourcingQualityPage";
import { AboutUsPage } from "./pages/AboutUsPage";
import { FaqPage } from "./pages/FaqPage";
import { ContactUsPage } from "./pages/ContactUsPage";

export default function App() {
  return (
    <BrowserRouter>
      <StructuredData />
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-emerald-800 focus:px-4 focus:py-2 focus:text-cream-50"
      >
        Skip to content
      </a>

      <Header />

      <main id="main" className="overflow-x-clip">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/products/:categoryId" element={<ProductListingPage />} />
          <Route path="/sourcing-and-quality" element={<SourcingQualityPage />} />
          <Route path="/about-us" element={<AboutUsPage />} />
          <Route path="/faq" element={<FaqPage />} />
          <Route path="/contact" element={<ContactUsPage />} />
        </Routes>
      </main>

      <Footer />
    </BrowserRouter>
  );
}
