const img = {
  hero: "/assets/hero-banner.png",
  premiumDatesCategory: "/assets/premium-dates-category.png",
  dateBasedProductsCategory: "/assets/date-based-products-category.png",
  wellnessFoodsCategory: "/assets/wellness-foods-category.png",
  honeyBlendsCategory: "/assets/honey-blends-category.png",
  fruitPreservesCategory: "/assets/fruit-preserves-category.png",
  kimiaDates: "/assets/kimia-dates.png",
  ajwaDates: "/assets/ajwa-dates.png",
  safawiDates: "/assets/safawi-dates.png",
  zahidiDates: "/assets/zahidi-dates.png",
  seedlessDates: "/assets/seedless-dates.png",
  desertRoyalDates: "/assets/desert-royal-dates.png",
  dateSyrup: "/assets/date-syrup.png",
  amlaCandy: "/assets/amla-candy.png",
  roseGulkand: "/assets/rose-gulkand.png",
  dryFruitWithHoney: "/assets/dry-fruit-with-honey.png",
  figHoneyDelight: "/assets/fig-honey-delight.png",
  mixedFruitJam: "/assets/mixed-fruit-jam.png",
  brandLegacy: "/assets/brand-legacy.png",
};

/** Square card — object-cover framing for pack shots */
const cover = { imageFit: "cover", imagePosition: "center" };
const dateSyrupCover = { imageFit: "cover", imagePosition: "center", imageScale: "fill" };

/** Default review meta for product cards */
function withReviews(product, reviewCount) {
  return {
    ...product,
    rating: product.rating ?? 4.7 + (reviewCount % 3) * 0.1,
    reviewCount: product.reviewCount ?? reviewCount,
  };
}

export const trustStrip = [
  { icon: "box", title: "Freshly Packed", text: "Sealed with care for every order" },
  { icon: "leaf", title: "Natural Ingredients", text: "Thoughtfully selected everyday foods" },
  { icon: "shield", title: "Secure Checkout", text: "Safe and simple online shopping" },
  { icon: "delivery", title: "Delivery Across India", text: "Nationwide dispatch on select ranges" },
];

export const shopCategories = [
  {
    title: "Premium Dates",
    products: "Kimia, Ajwa, Safawi, Zahidi, Seedless Dates",
    cta: "Shop Dates",
    href: "#premium-dates",
    img: img.premiumDatesCategory,
    featured: true,
  },
  {
    title: "Date-Based Products",
    products: "Date Syrup, Ajwa Seed Powder",
    cta: "Explore Date Products",
    href: "#premium-dates",
    img: img.dateBasedProductsCategory,
    featured: true,
  },
  {
    title: "Traditional Wellness Foods",
    products: "Amla Candy, Rose Gulkand, Health Mix",
    cta: "Shop Wellness",
    href: "#wellness-products",
    img: img.wellnessFoodsCategory,
    featured: true,
  },
  {
    title: "Honey & Natural Blends",
    products: "Dry Fruit with Honey, Fig & Honey Delight",
    cta: "View Blends",
    href: "#wellness-products",
    img: img.honeyBlendsCategory,
    featured: true,
  },
  {
    title: "Fruit Preserves",
    products: "Mixed Fruit Jam",
    cta: "Shop Preserves",
    href: "#wellness-products",
    img: img.fruitPreservesCategory,
    featured: true,
  },
];

export const premiumDates = [
  withReviews({ name: "Kimia Dates", tagline: "Soft & Juicy", tag: "Soft", img: img.kimiaDates, price: "₹ —", packSize: "1kg", ...cover }, 248),
  withReviews({ name: "Ajwa Dates", tagline: "Rich & Premium", tag: "Premium", img: img.ajwaDates, price: "₹ —", packSize: "1kg" }, 312),
  withReviews({ name: "Safawi Dates", tagline: "Dark & Chewy", tag: "Premium", img: img.safawiDates, price: "₹ —", packSize: "1kg" }, 189),
  withReviews({ name: "Zahidi Dates", tagline: "Mildly Sweet", tag: "Natural Sweetness", img: img.zahidiDates, price: "₹ —", packSize: "Pouch", ...cover }, 156),
  withReviews({ name: "Seedless Dates", tagline: "Easy Everyday Snacking", tag: "Seedless", img: img.seedlessDates, price: "₹ —", packSize: "Pouch", ...cover }, 203),
  withReviews({ name: "Desert Royal Dates", tagline: "Naturally Sweet", tag: "Everyday Snack", img: img.desertRoyalDates, price: "₹ —", packSize: "Pouch", ...cover }, 174),
];

export const wellnessProducts = [
  withReviews({
    name: "Date Syrup",
    tagline: "Natural sweetener for drinks, desserts, and breakfast",
    img: img.dateSyrup,
    ...dateSyrupCover,
    price: "₹ —",
    packSize: "400g",
  }, 142),
  withReviews({
    name: "Amla Candy",
    tagline: "Tangy traditional snack for everyday munching",
    img: img.amlaCandy,
    price: "₹ —",
    packSize: "250g",
  }, 98),
  withReviews({
    name: "Rose Gulkand",
    tagline: "Aromatic preserve with a traditional taste",
    img: img.roseGulkand,
    price: "₹ —",
    packSize: "250g",
  }, 121),
  withReviews({
    name: "Dry Fruit with Honey",
    tagline: "Rich natural blend for wellness and gifting",
    img: img.dryFruitWithHoney,
    imageFit: "contain",
    price: "₹ —",
    packSize: "250g",
  }, 87),
  withReviews({
    name: "Fig & Honey Delight",
    tagline: "Sweet, rich, and wholesome treat",
    img: img.figHoneyDelight,
    imageFit: "contain",
    price: "₹ —",
    packSize: "250g",
  }, 76),
  withReviews({
    name: "Mixed Fruit Jam",
    tagline: "Family-friendly spread for breakfast",
    img: img.mixedFruitJam,
    ...cover,
    price: "₹ —",
    packSize: "100g",
  }, 134),
];

export const customerFavourites = [
  withReviews({ name: "Kimia Dates", tagline: "Soft & Juicy", img: img.kimiaDates, ...cover, price: "₹ —", packSize: "1kg" }, 248),
  withReviews({ name: "Ajwa Dates", tagline: "Rich & Premium", img: img.ajwaDates, price: "₹ —", packSize: "1kg" }, 312),
  withReviews({ name: "Seedless Dates", tagline: "Easy Everyday Snacking", img: img.seedlessDates, ...cover, price: "₹ —", packSize: "Pouch" }, 203),
  withReviews({ name: "Date Syrup", tagline: "Natural sweetener for everyday use", img: img.dateSyrup, ...dateSyrupCover, price: "₹ —", packSize: "400g" }, 142),
  withReviews({ name: "Amla Candy", tagline: "Tangy traditional snack", img: img.amlaCandy, price: "₹ —", packSize: "250g" }, 98),
  withReviews({ name: "Rose Gulkand", tagline: "Aromatic traditional preserve", img: img.roseGulkand, price: "₹ —", packSize: "250g" }, 121),
  withReviews({ name: "Dry Fruit with Honey", tagline: "Rich natural wellness blend", img: img.dryFruitWithHoney, imageFit: "contain", price: "₹ —", packSize: "250g" }, 87),
  withReviews({ name: "Mixed Fruit Jam", tagline: "Family-friendly breakfast spread", img: img.mixedFruitJam, ...cover, price: "₹ —", packSize: "100g" }, 134),
];

export const shopByNeed = [
  { need: "Daily Healthy Snacking", products: "Kimia Dates / Seedless Dates", href: "#premium-dates" },
  { need: "Premium Date Choice", products: "Ajwa Dates / Safawi Dates", href: "#premium-dates" },
  { need: "Natural Sweetener", products: "Date Syrup", href: "#wellness-products" },
  { need: "Traditional Taste", products: "Amla Candy / Rose Gulkand", href: "#wellness-products" },
  { need: "Breakfast Add-on", products: "Mixed Fruit Jam", href: "#wellness-products" },
  { need: "Rich Natural Blend", products: "Dry Fruit with Honey / Fig & Honey Delight", href: "#wellness-products" },
];

export { img as homepageImages };
