/** Primary site navigation */

export const mainNav = [
  { label: "Home", href: "/" },
  { label: "Product", href: "/products/dates", megaMenu: true },
  { label: "Sourcing and Quality", href: "/sourcing-and-quality" },
  { label: "About us", href: "/about-us" },
  { label: "FAQ", href: "/faq" },
  { label: "Blog", href: "/#blog" },
  { label: "Contact us", href: "/contact" },
];
