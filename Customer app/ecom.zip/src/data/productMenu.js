import {
  premiumDates,
  wellnessProducts,
  customerFavourites,
} from "./homepage";

function withId(products, prefix) {
  return products.map((p) => ({
    ...p,
    id: `${prefix}-${p.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
  }));
}

/** Everyday & pouch date varieties */
const datesProducts = withId(
  premiumDates.filter((p) =>
    ["Zahidi Dates", "Seedless Dates", "Desert Royal Dates"].includes(p.name)
  ),
  "dates"
);

/** Premium boxed dates */
const premiumDatesProducts = withId(
  premiumDates.filter((p) => ["Kimia Dates", "Ajwa Dates", "Safawi Dates"].includes(p.name)),
  "premium"
);

export const productMenuCategories = [
  {
    id: "dates",
    label: "Dates",
    description: "Everyday snacking and family favourites",
    viewAllHref: "/products/dates",
    products: datesProducts,
  },
  {
    id: "premium-dates",
    label: "Premium Dates",
    description: "Soft, rich, and gift-worthy varieties",
    viewAllHref: "/products/premium-dates",
    products: premiumDatesProducts,
  },
  {
    id: "wellness-traditional",
    label: "Wellness & Traditional",
    description: "Natural foods for daily wellness",
    viewAllHref: "/products/wellness-traditional",
    products: withId(wellnessProducts, "wellness"),
  },
  {
    id: "best-sellers",
    label: "Best Sellers",
    description: "Customer favourites across our range",
    viewAllHref: "/products/best-sellers",
    products: withId(customerFavourites, "bestseller"),
  },
];

export function getCategoryById(categoryId) {
  return productMenuCategories.find((c) => c.id === categoryId) ?? null;
}
