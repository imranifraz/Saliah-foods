export const blogPosts = [
  {
    id: "kimia-dates-benefits",
    title: "Why Kimia Dates Are Perfect for Everyday Snacking",
    excerpt:
      "Soft, naturally sweet, and packed with energy — discover how Kimia dates fit into your daily routine and family table.",
    date: "May 8, 2026",
    category: "Wellness",
    href: "/#blog",
    img: "/assets/kimia-dates.png",
  },
  {
    id: "date-syrup-uses",
    title: "5 Simple Ways to Use Date Syrup at Home",
    excerpt:
      "From morning smoothies to dessert drizzles, date syrup is a natural sweetener your kitchen will love.",
    date: "Apr 22, 2026",
    category: "Recipes",
    href: "/#blog",
    img: "/assets/date-syrup.png",
  },
  {
    id: "traditional-wellness",
    title: "Rose Gulkand & Amla Candy: Traditional Foods for Modern Living",
    excerpt:
      "Explore timeless wellness foods that bring authentic taste and everyday nourishment to your home.",
    date: "Apr 10, 2026",
    category: "Traditional",
    href: "/#blog",
    img: "/assets/rose-gulkand.png",
  },
];
