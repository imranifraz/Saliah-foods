import { lazy, Suspense, useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { mainNav } from "../../data/navigation";
import { productMenuCategories } from "../../data/productMenu";

const ProductMegaMenu = lazy(() =>
  import("./ProductMegaMenu").then((m) => ({ default: m.ProductMegaMenu }))
);

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [mobileProductsOpen, setMobileProductsOpen] = useState(false);
  const megaRef = useRef(null);
  const outsideHandlerRef = useRef(null);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  useEffect(() => {
    setMegaOpen(false);
    setMenuOpen(false);
    setMobileProductsOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!megaOpen) return undefined;
    const onKey = (e) => {
      if (e.key === "Escape") setMegaOpen(false);
    };
    const timer = window.setTimeout(() => {
      const onPointerDown = (e) => {
        if (megaRef.current && !megaRef.current.contains(e.target)) setMegaOpen(false);
      };
      outsideHandlerRef.current = onPointerDown;
      document.addEventListener("mousedown", onPointerDown);
    }, 0);
    document.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(timer);
      if (outsideHandlerRef.current) {
        document.removeEventListener("mousedown", outsideHandlerRef.current);
        outsideHandlerRef.current = null;
      }
      document.removeEventListener("keydown", onKey);
    };
  }, [megaOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header
      ref={megaRef}
      className={`fixed inset-x-0 top-0 z-50 bg-transparent transition-all duration-500 ${
        scrolled ? "py-1.5" : "py-2"
      }`}
    >
      <motion.div
        className={`mx-auto max-w-[1440px] px-4 transition-all duration-500 sm:px-5 md:px-10 ${
          scrolled
            ? "rounded-full bg-white/85 shadow-luxury backdrop-blur-md"
            : "bg-transparent"
        }`}
      >
        <div className="flex h-[var(--site-header)] items-center justify-between gap-2 sm:gap-3 md:gap-4">
          <Link to="/" className="relative z-10 max-w-[42%] shrink-0 sm:max-w-none" aria-label="Saliah Foods home">
            <img
              src="/assets/saliah-logo.webp"
              alt="Saliah Foods"
              className="h-16 w-auto sm:h-[4.5rem] md:h-20 lg:h-[5.5rem] xl:h-24"
              width={240}
              height={120}
              decoding="async"
              fetchPriority="low"
            />
          </Link>

          <nav
            className="hidden flex-1 items-center justify-center gap-3 xl:flex xl:gap-6 2xl:gap-8"
            aria-label="Primary"
          >
            {mainNav.map((item) =>
              item.megaMenu ? (
                <button
                  key={item.label}
                  type="button"
                  className={`shrink-0 font-body text-xs font-medium uppercase tracking-[0.12em] transition-colors duration-300 ${
                    megaOpen ? "text-emerald-800" : "text-emerald-900/70 hover:text-emerald-800"
                  }`}
                  aria-expanded={megaOpen}
                  aria-haspopup="dialog"
                  onClick={() => setMegaOpen((v) => !v)}
                >
                  {item.label}
                </button>
              ) : (
                <Link
                  key={item.label}
                  to={item.href}
                  className="shrink-0 font-body text-xs font-medium uppercase tracking-[0.12em] text-emerald-900/70 transition-colors duration-300 hover:text-emerald-800"
                >
                  {item.label}
                </Link>
              )
            )}
          </nav>

          <div className="flex shrink-0 items-center gap-1.5 sm:gap-2 md:gap-3">
            <button type="button" className="hidden h-9 w-9 items-center justify-center rounded-full bg-emerald-900/5 text-emerald-900 sm:flex" aria-label="Search">
              <IconSearch />
            </button>
            <button type="button" className="hidden h-9 w-9 items-center justify-center rounded-full bg-emerald-900/5 text-emerald-900 sm:flex" aria-label="Account">
              <IconUser />
            </button>
            <button type="button" className="relative flex h-9 min-w-[36px] items-center justify-center gap-2 rounded-full gradient-gold px-3 font-body text-[10px] font-semibold uppercase tracking-[0.14em] text-white sm:min-w-[40px] sm:px-4 md:min-w-[100px]" aria-label="Cart, 0 items">
              <IconBag />
              <span className="hidden sm:inline">Cart</span>
              <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-900 text-[10px] font-bold text-cream-50">0</span>
            </button>
            <button type="button" className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-900/5 text-emerald-900 xl:hidden" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen((v) => !v)}>
              {menuOpen ? <IconClose /> : <IconMenu />}
            </button>
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {megaOpen ? (
          <Suspense fallback={null}>
            <ProductMegaMenu onClose={() => setMegaOpen(false)} />
          </Suspense>
        ) : null}
      </AnimatePresence>

      <AnimatePresence>
        {menuOpen ? (
          <>
            <motion.button type="button" className="fixed inset-0 z-40 bg-emerald-950/40 backdrop-blur-sm xl:hidden" aria-label="Close menu" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={closeMenu} />
            <motion.nav className="fixed inset-x-0 top-[calc(var(--site-header)+0.5rem)] z-50 mx-4 max-h-[min(80vh,640px)] overflow-y-auto rounded-2xl border border-cream-200 bg-cream-50 p-4 shadow-luxury-lg sm:mx-5 xl:hidden" aria-label="Mobile" initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
              <ul className="flex flex-col gap-1">
                <li>
                  <button type="button" className="flex w-full items-center justify-between rounded-xl px-4 py-3.5 font-body text-base font-medium text-emerald-900" onClick={() => setMobileProductsOpen((v) => !v)} aria-expanded={mobileProductsOpen}>
                    Products
                    <span className="text-emerald-900/40">{mobileProductsOpen ? "−" : "+"}</span>
                  </button>
                  {mobileProductsOpen ? (
                    <ul className="mb-2 ml-2 space-y-1 border-l border-cream-200 pl-3">
                      {productMenuCategories.map((cat) => (
                        <li key={cat.id}>
                          <Link to={cat.viewAllHref} className="block rounded-lg px-3 py-2.5 font-body text-[15px] text-emerald-900/80 hover:bg-cream-100" onClick={closeMenu}>
                            {cat.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </li>
                {mainNav.filter((i) => !i.megaMenu).map((item) => (
                  <li key={item.label}>
                    <Link to={item.href} className="block rounded-xl px-4 py-3.5 font-body text-base font-medium text-emerald-900 hover:bg-cream-100" onClick={closeMenu}>
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.nav>
          </>
        ) : null}
      </AnimatePresence>
    </header>
  );
}

function IconMenu() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <path d="M4 7h16M4 12h16M4 17h16" />
    </svg>
  );
}

function IconClose() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <path d="M6 6l12 12M18 6L6 18" />
    </svg>
  );
}

function IconSearch() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <circle cx="11" cy="11" r="7" />
      <path d="M20 20l-4-4" />
    </svg>
  );
}

function IconUser() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden>
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

function IconBag() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden>
      <path d="M6 6h15l-1.5 9h-12z" />
      <circle cx="9" cy="20" r="1" />
      <circle cx="18" cy="20" r="1" />
    </svg>
  );
}
