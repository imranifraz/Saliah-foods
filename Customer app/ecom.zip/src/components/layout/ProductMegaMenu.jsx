﻿import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { productMenuCategories } from "../../data/productMenu";
import { OptimizedImage } from "../ui/OptimizedImage";

export function ProductMegaMenu({ onClose }) {
  const [activeId, setActiveId] = useState(productMenuCategories[0].id);
  const active = productMenuCategories.find((c) => c.id === activeId) ?? productMenuCategories[0];
  const previewProducts = active.products.slice(0, 6);

  return (
    <motion.div
      role="dialog"
      aria-label="Product categories"
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
      className="absolute left-0 right-0 top-full z-[60] mt-3 hidden px-4 sm:px-5 md:px-10 xl:block"
    >
      <div className="mx-auto max-w-[1440px]">
        <div className="overflow-hidden rounded-2xl border border-cream-200 bg-cream-50 shadow-luxury-lg">
          <div className="grid min-h-[320px] grid-cols-[220px_1fr]">
            <ul className="border-r border-cream-200 bg-cream-100/60 p-3" role="list">
              {productMenuCategories.map((cat) => (
                <li key={cat.id}>
                  <button
                    type="button"
                    className={`w-full rounded-xl px-4 py-3.5 text-left transition-colors ${
                      activeId === cat.id
                        ? "bg-emerald-900 text-cream-50"
                        : "text-emerald-900 hover:bg-cream-50"
                    }`}
                    onMouseEnter={() => setActiveId(cat.id)}
                    onFocus={() => setActiveId(cat.id)}
                    onClick={() => setActiveId(cat.id)}
                  >
                    <span className="block font-body text-sm font-semibold">{cat.label}</span>
                    <span
                      className={`mt-0.5 block font-body text-[11px] leading-snug ${
                        activeId === cat.id ? "text-cream-50/70" : "text-emerald-900/50"
                      }`}
                    >
                      {cat.description}
                    </span>
                  </button>
                </li>
              ))}
            </ul>

            <div className="flex flex-col p-5 md:p-6">
              <div className="mb-4">
                <h3 className="font-display text-xl font-medium text-emerald-900">{active.label}</h3>
                <p className="mt-1 font-body text-sm text-emerald-900/60">{active.description}</p>
              </div>

              <div className="grid flex-1 grid-cols-3 gap-3">
                {previewProducts.map((product) => (
                  <Link
                    key={product.id}
                    to={active.viewAllHref}
                    className="group flex flex-col overflow-hidden rounded-xl border border-cream-200 bg-cream-50 transition-shadow hover:shadow-luxury"
                    onClick={onClose}
                  >
                    <div className="aspect-square overflow-hidden bg-cream-100">
                      <OptimizedImage
                        src={product.img}
                        alt={product.name}
                        className={`h-full w-full ${
                          product.imageFit === "contain" ? "object-contain p-2" : "object-cover object-center"
                        }`}
                        width={200}
                        height={200}
                      />
                    </div>
                    <div className="p-2.5">
                      <p className="font-body text-xs font-semibold leading-snug text-emerald-900 group-hover:text-emerald-800">
                        {product.name}
                      </p>
                      {product.packSize ? (
                        <p className="mt-0.5 font-body text-[10px] uppercase tracking-wider text-emerald-900/45">
                          {product.packSize}
                        </p>
                      ) : null}
                      <p className="mt-1 font-body text-xs font-semibold text-emerald-900">{product.price}</p>
                    </div>
                  </Link>
                ))}
              </div>

              <div className="mt-4 flex justify-end">
                <Link
                  to={active.viewAllHref}
                  className="inline-flex rounded-full border border-emerald-900/15 bg-cream-50 px-6 py-2.5 font-body text-[10px] font-semibold uppercase tracking-[0.14em] text-emerald-900 transition-colors hover:border-emerald-800 hover:bg-emerald-900 hover:text-cream-50"
                  onClick={onClose}
                >
                  View all
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
