/**
 * Serves WebP when available (generated via npm run optimize:images), PNG fallback.
 */
export function OptimizedImage({
  src,
  alt,
  className = "",
  priority = false,
  sizes,
  width,
  height,
  ...props
}) {
  const webpSrc = src?.replace(/\.png$/i, ".webp");

  return (
    <picture className="block h-full w-full">
      {webpSrc ? <source srcSet={webpSrc} type="image/webp" /> : null}
      <img
        src={src}
        alt={alt}
        className={className}
        width={width}
        height={height}
        sizes={sizes}
        decoding="async"
        loading={priority ? "eager" : "lazy"}
        fetchPriority={priority ? "high" : undefined}
        {...props}
      />
    </picture>
  );
}
