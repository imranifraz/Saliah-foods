import { Link } from "react-router-dom";
import { motion, useReducedMotion } from "framer-motion";
import { OptimizedImage } from "./OptimizedImage";

/**
 * @typedef {Object} Product
 * @property {string} name
 * @property {string} [tagline]
 * @property {string} [description]
 * @property {number} [rating]
 * @property {number} [reviewCount]
 * @property {string} [tag]
 * @property {string} img
 * @property {string} price
 * @property {string} [salePrice]
 * @property {string} [packSize]
 * @property {string} [badge]
 * @property {'cover' | 'contain'} [imageFit]
 * @property {'center' | 'top' | 'bottom'} [imagePosition]
 * @property {'fill'} [imageScale]
 */

const positionClass = {
  center: "object-center",
  top: "object-top",
  bottom: "object-bottom",
};

function StarRating({ rating = 4.8, small = false }) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5;
  const size = small ? "h-2.5 w-2.5" : "h-3.5 w-3.5";

  return (
    <div className="flex items-center gap-0.5" aria-hidden>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg
          key={i}
          className={`${size} ${i < full ? "text-gold-500" : i === full && half ? "text-gold-400" : "text-cream-200"}`}
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

function HandPointerIcon({ size = 24 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M10.5 3.75a1.5 1.5 0 0 1 3 0v5.25H18a1.5 1.5 0 0 1 1.5 1.5v2.25c0 .83-.67 1.5-1.5 1.5h-1.06l.28 1.69a1.5 1.5 0 0 1-1.48 1.81H9.75a1.5 1.5 0 0 1-1.5-1.5v-9A1.5 1.5 0 0 1 9.75 3.75h.75Z" />
    </svg>
  );
}

export function ProductCard({
  product,
  index = 0,
  showPackSize = false,
  showTagline = true,
  compact = false,
  detailHref,
  className = "",
}) {
  const reduce = useReducedMotion();
  const fitContain = product.imageFit === "contain";
  const fillFrame = product.imageScale === "fill";
  const objectPosition = positionClass[product.imagePosition ?? "center"];
  const rating = product.rating ?? 4.8;
  const reviewCount = product.reviewCount ?? 0;
  const description = product.description ?? product.tagline ?? "";

  return (
    <motion.article
      className={`group flex h-full min-w-0 cursor-pointer flex-col ${className}`}
      initial={reduce ? false : { opacity: 0, y: 24 }}
      whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.7, delay: index * 0.06, ease: [0.22, 1, 0.36, 1] }}
    >
      <div
        className={`relative overflow-hidden bg-cream-100 ${compact ? "rounded-lg shadow-md" : "rounded-2xl shadow-luxury"}`}
      >
        <motion.div
          className={`relative overflow-hidden ${
            fitContain ? "aspect-square bg-cream-50" : "aspect-square"
          }`}
        >
          {(product.tag || product.badge) && (
            <span
              className={`absolute z-10 rounded-full bg-cream-50/95 font-body font-semibold uppercase tracking-[0.16em] text-emerald-900 ${
                compact ? "left-2 top-2 px-2 py-0.5 text-[8px]" : "left-3 top-3 px-2.5 py-1 text-[9px]"
              }`}
            >
              {product.badge || product.tag}
            </span>
          )}
          <motion.div
            className={`h-full w-full ${fitContain ? (compact ? "p-2" : "p-4") : fillFrame ? (compact ? "scale-[1.08]" : "scale-[1.12]") : ""}`}
            whileHover={reduce ? undefined : { scale: fitContain ? 1.03 : 1.05 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            <OptimizedImage
              src={product.img}
              alt={product.name}
              className={
                fitContain
                  ? "h-full w-full object-contain object-center"
                  : `h-full w-full object-cover ${objectPosition}`
              }
              width={compact ? 360 : 600}
              height={compact ? 360 : 600}
            />
          </motion.div>

          {detailHref ? (
            <Link
              to={detailHref}
              className="absolute inset-0 z-20 flex cursor-pointer items-center justify-center bg-emerald-950/0 opacity-0 transition-all duration-300 group-hover:bg-emerald-950/20 group-hover:opacity-100 focus-visible:bg-emerald-950/25 focus-visible:opacity-100"
              aria-label={`View ${product.name}`}
            >
              <span
                className={`flex scale-90 items-center justify-center rounded-full bg-cream-50 text-emerald-900 shadow-luxury-lg transition-transform duration-300 group-hover:scale-100 ${
                  compact ? "h-8 w-8" : "h-12 w-12"
                }`}
              >
                <HandPointerIcon size={compact ? 18 : 24} />
              </span>
            </Link>
          ) : (
            <button
              type="button"
              className="absolute inset-0 z-20 flex cursor-pointer items-center justify-center bg-emerald-950/0 opacity-0 transition-all duration-300 group-hover:bg-emerald-950/20 group-hover:opacity-100 focus-visible:bg-emerald-950/25 focus-visible:opacity-100"
              aria-label={`View ${product.name}`}
            >
              <span
                className={`flex scale-90 items-center justify-center rounded-full bg-cream-50 text-emerald-900 shadow-luxury-lg transition-transform duration-300 group-hover:scale-100 ${
                  compact ? "h-8 w-8" : "h-12 w-12"
                }`}
              >
                <HandPointerIcon size={compact ? 18 : 24} />
              </span>
            </button>
          )}
        </motion.div>
      </div>

      <div className={`flex flex-1 flex-col px-0.5 ${compact ? "pt-2" : "pt-4"} min-h-0`}>
        <h3
          className={`font-display font-medium leading-snug text-emerald-900 group-hover:text-emerald-800 ${
            compact ? "text-sm sm:text-base" : "text-base sm:text-lg"
          }`}
        >
          {product.name}
        </h3>

        {description ? (
          <p
            className={`font-body leading-relaxed text-emerald-900/60 ${
              compact ? "mt-0.5 line-clamp-1 text-[11px]" : "mt-1.5 line-clamp-2 text-sm"
            }`}
          >
            {showTagline && product.tagline ? product.tagline : description}
          </p>
        ) : null}

        <div className={`flex flex-wrap items-center gap-1.5 ${compact ? "mt-1.5" : "mt-2.5"}`}>
          <StarRating rating={rating} small={compact} />
          <span className={`font-body font-medium text-emerald-900 ${compact ? "text-[10px]" : "text-xs"}`}>
            {rating.toFixed(1)}
          </span>
          {!compact && reviewCount > 0 ? (
            <span className="font-body text-xs text-emerald-900/45">({reviewCount} reviews)</span>
          ) : null}
        </div>

        {showPackSize && product.packSize ? (
          <p
            className={`font-body uppercase tracking-[0.12em] text-emerald-900/45 ${
              compact ? "mt-1 text-[9px]" : "mt-2 text-[10px]"
            }`}
          >
            {product.packSize}
          </p>
        ) : null}

        <div className={`flex items-baseline gap-2 ${compact ? "mt-1.5" : "mt-3"}`}>
          {product.salePrice ? (
            <>
              <span className={`font-body font-semibold text-emerald-900 ${compact ? "text-sm" : "text-base"}`}>
                {product.salePrice}
              </span>
              <span className={`font-body text-emerald-900/40 line-through ${compact ? "text-xs" : "text-sm"}`}>
                {product.price}
              </span>
            </>
          ) : (
            <span className={`font-body font-semibold text-emerald-900 ${compact ? "text-sm" : "text-base"}`}>
              {product.price}
            </span>
          )}
        </div>

        <motion.div className={`mt-auto flex flex-col gap-2 pt-3 sm:pt-4 ${compact ? "gap-1.5" : ""}`}>
          <motion.button
            type="button"
            className={`w-full flex-1 rounded-full gradient-gold font-body font-semibold uppercase tracking-[0.16em] text-white shadow-md shadow-gold-500/20 transition-shadow hover:shadow-lg hover:shadow-gold-500/30 sm:tracking-[0.18em] ${
              compact ? "py-2.5 text-[10px]" : "py-3.5 text-[11px]"
            }`}
            whileTap={reduce ? undefined : { scale: 0.99 }}
          >
            Add to cart
          </motion.button>
          <motion.button
            type="button"
            className={`w-full flex-1 rounded-full border border-emerald-900/15 bg-transparent font-body font-semibold uppercase tracking-[0.14em] text-emerald-900/80 transition-colors hover:border-emerald-800 hover:bg-cream-100 hover:text-emerald-900 sm:tracking-[0.16em] ${
              compact ? "py-2 text-[9px]" : "py-2.5 text-[10px]"
            }`}
            whileTap={reduce ? undefined : { scale: 0.99 }}
          >
            Buy now
          </motion.button>
        </motion.div>
      </div>
    </motion.article>
  );
}
